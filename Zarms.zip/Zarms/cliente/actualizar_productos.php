<?php
// Configuración de conexión a la base de datos
$servername = "b9adcso2ssjiqbhrwytf-mysql.services.clever-cloud.com";
$username = "uzd4kdukd76ffseo";
$password = "lXa5hn5RkrINOzg9yDaN";
$dbname = "b9adcso2ssjiqbhrwytf";

// Crear la conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Función para actualizar el estado de un producto
function actualizarEstadoProducto($conn, $id_producto) {
    // Consultar la cantidad actual del producto
    $sql = "SELECT cantidad FROM producto WHERE id_producto = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_producto);
    $stmt->execute();
    $stmt->bind_result($cantidad);
    $stmt->fetch();
    $stmt->close();

    // Verificar si la cantidad es menor que 0 y establecer en 0 si es necesario
    if ($cantidad < 0) {
        $cantidad = 0;
    }

    // Verificar si la cantidad es 0 o mayor a 0 y actualizar el estado
    if ($cantidad == 0) {
        // Cambiar estado a 'Inactivo' si la cantidad es 0
        $sql_update = "UPDATE producto SET estado = 'Inactivo', cantidad = 0 WHERE id_producto = ?";
    } else {
        // Cambiar estado a 'Activo' si la cantidad es mayor a 0
        $sql_update = "UPDATE producto SET estado = 'Activo', cantidad = ? WHERE id_producto = ?";
    }

    // Ejecutar la actualización
    $stmt_update = $conn->prepare($sql_update);
    if ($cantidad == 0) {
        $stmt_update->bind_param("i", $id_producto);
    } else {
        $stmt_update->bind_param("ii", $cantidad, $id_producto);
    }
    $stmt_update->execute();
    $stmt_update->close();
}

// Obtener todos los productos para verificar sus cantidades y actualizar su estado
$sql = "SELECT id_producto FROM producto";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Iterar sobre todos los productos
    while($row = $result->fetch_assoc()) {
        actualizarEstadoProducto($conn, $row["id_producto"]);
    }
} else {
    echo "No se encontraron productos.";
}

// Cerrar la conexión
$conn->close();
?>

<!-- Diseño estilizado para la cuenta regresiva -->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cuenta Regresiva</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #282c34;
            color: white;
            font-family: 'Arial', sans-serif;
        }

        .contador {
            text-align: center;
        }

        .contador p {
            font-size: 24px;
            color: #61dafb;
        }

        #contador {
            font-size: 100px;
            font-weight: bold;
            margin-top: 20px;
            color: #61dafb;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }

        /* Animación */
        #contador {
            animation: pulse 1s infinite;
        }

        @keyframes pulse {
            0% {
                transform: scale(1);
            }
            50% {
                transform: scale(1.1);
            }
            100% {
                transform: scale(1);
            }
        }
    </style>
</head>
<body>

<div class="contador">
    <p>La página se recargará en</p>
    <span id="contador">10</span>
    <p>segundos.</p>
</div>

<script type="text/javascript">
    var tiempoRestante = 10; // Tiempo inicial en segundos

    // Función para actualizar la cuenta regresiva
    function actualizarCuentaRegresiva() {
        if (tiempoRestante > 0) {
            tiempoRestante--;
            document.getElementById("contador").innerHTML = tiempoRestante;
        } else {
            // Recargar la página cuando el tiempo llegue a 0
            window.location.reload();
        }
    }

    // Llamar a la función cada segundo
    setInterval(actualizarCuentaRegresiva, 1000); // 1000 milisegundos = 1 segundo
</script>

</body>
</html>
