<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php'; // Asegúrate de incluir el archivo autoload de Composer.

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $emails = $_POST['email'];  // Esto es un array de correos electrónicos
    $subject = $_POST['subject'];
    $message = $_POST['message'];

    $mail = new PHPMailer(true);

    try {
        // Configuración del servidor SMTPQ
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'em9845368@gmail.com';
        $mail->Password = 'zhve fadx pfnt sfve';  // Tu contraseña de aplicación
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Remitente
        $mail->setFrom('em9845368@gmail.com', 'Edgar Adolfo Mejia Enamorado');

        // Agregar destinatarios
        foreach ($emails as $email) {
            $mail->addAddress($email);
        }

        // Contenido del correo
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $message;

        // Enviar el correo
        $mail->send();
        
        // Redirigir a correo.html con mensaje de éxito
        header("Location: correo.html?status=success");
    } catch (Exception $e) {
        // Redirigir a correo.html con mensaje de error
        header("Location: correo.html?status=error");
    }
}
?>
