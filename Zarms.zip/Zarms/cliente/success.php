<?php
require 'vendor/autoload.php';

$apiContext = new \PayPal\Rest\ApiContext(
    new \PayPal\Auth\OAuthTokenCredential(
        'AdEiQhI8J-GZZ5kev2becSu_dbrd6JHuYYBhtWeiWCnW9VbDzRi85ypsK6ppn-p30iykGuBogvauvzjh',     // El Client ID de tu aplicación de PayPal
                    'EHSqFV4kj5OnR7n0gbv21Cbx5Hq-TAEWwYuxXujM-CQPt2w7OM4u-yShDOcAf9ZEozaT9KDDtJcOQFQS'      // El Secret de tu aplicación de PayPal
    )
);

if (isset($_GET['paymentId']) && isset($_GET['PayerID'])) {
    $paymentId = $_GET['paymentId'];
    $payerId = $_GET['PayerID'];

    $payment = \PayPal\Api\Payment::get($paymentId, $apiContext);

    $execution = new \PayPal\Api\PaymentExecution();
    $execution->setPayerId($payerId);

    try {
        // Ejecutar el pago
        $result = $payment->execute($execution, $apiContext);
        echo "Pago completado correctamente.";
    } catch (Exception $ex) {
        echo "Error al completar el pago.";
        exit(1);
    }
}
?>
