<?php
// Inicia la sesión si es necesario
session_start();

// Incluye cualquier archivo necesario para la conexión a la base de datos si es necesario
// include 'db_connection.php';

// Mensaje de cancelación del pago
echo "<h2>El pago ha sido cancelado</h2>";
echo "<p>Lamentamos que hayas cancelado el proceso de pago. Si deseas intentarlo nuevamente, puedes realizar tu pedido desde tu carrito de compras.</p>";
echo "<a href='carrito.php' class='btn btn-primary'>Volver al Carrito</a>"; // Supongamos que tienes una página de carrito de compras

// También puedes redirigir automáticamente al carrito de compras o a otra página si lo prefieres
// header('Location: cart.php');  // Descomenta esta línea si prefieres redirigir al usuario
?>
